﻿'use strict';

const AWS = require('aws-sdk');
AWS.config.region = 'us-west-2';

const dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
require('./dal').test('load');
function getDoneFunction(callback) {
    return (err, res) => callback(null, {
        statusCode: err ? '400' : '200',
        body: err ? err.message : JSON.stringify({ res }),
        headers: {
            'Content-Type': 'application/json',
        },
    });
}

exports.resetPassword = (event, context, callback) => {
    const done = getDoneFunction(callback);
    getUserById(event.body.ID)
        .then((evt) => {
            const item = evt.data && evt.data.Item;

            if (evt.err) {
                done(evt.err);
            } else if (!item) {
                done(null, { userExist: false });
            } else if (item.email || item.cellphoneNumber){
                createUserPassword(event.body.ID, item.email && item.email.S, item.cellphoneNumber && item.cellphoneNumber.S)
                    .then((evt) => {
                        done(evt.err, {
                            userExist: true,
                            hasPassword: false,
                            passwordSend: true,
                            sendPasswordTo: item.email ? 'email' : 'sms'
                        });
                    });
            }
        });
}

exports.searchUserById = (event, context, callback) => {
    const done = getDoneFunction(callback);
    const body = event.body || {};

    if (!body.ID) {
        done('require body with ID param');
    } else {
        getUserById(body.ID)
        .then((evt) => {
            const item = evt.data && evt.data.Item;

            if (evt.err) {
                done(evt.err);
            } else if (!item) {
                done(null, { userExist: false });
            } else if (item.password) {
                done(null, { userExist: true, hasPassword: true });
            } else if (item.email || item.cellphoneNumber) {
                createUserPassword(body.ID, item.email && item.email.S, item.cellphoneNumber && item.cellphoneNumber.S)
                    .then((evt) => {
                        done(evt.err, {
                            userExist: true,
                            hasPassword: false,
                            passwordSend: true,
                            sendPasswordTo: item.email ? 'email' : 'sms'
                        });
                    });
            } else {
                done(null, {
                    userExist: true,
                    hasPassword: false,
                    passwordSend: false
                });
            }
        });
    }
};

function createUserPassword(ID, mailAddress, phoneNumber) {
    const password = generatePassword();
    const params = {
        TableName: 'Users',
        Key: {
            ID: {
                S: ID
            }
        },
        UpdateExpression: 'SET #p = :p',
        ExpressionAttributeNames: {
            "#p": "password"
        },
        ExpressionAttributeValues: {
            ":p": {
                S: password
            }
        }
    };

    const promise = new Promise((resolve, reject) => {
        dynamodb.updateItem(params, (err, data) => {
            const msg = `סיסמתך החדשה לאתר סקר סופרים היא ${password}.`;
            if (err) {
                resolve({ err });
            } else if (mailAddress) {
                sendMail(mailAddress, 'סיסמה חדשה לאתר סקר סופרים', msg)
                    .then(resolve);
            } else if (phoneNumber) {
                sendSMS(msg, phoneNumber)
                    .then(resolve);
            }
        });
    });
    return promise;
}

function generatePassword() {
    return String.fromCharCode(65 + Math.floor(Math.random() * 26)) +
        String.fromCharCode(97 + Math.floor(Math.random() * 26)) +
        Math.random().toString().substring(2, 7);
}

function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}


function sendMail(to, subject, text) {
    const ses = new AWS.SES({ apiVersion: '2010-12-01' });
    var params = {
        Destination: {
            BccAddresses: [
                'eladheller@gmail.com'
            ],
            ToAddresses: ['eladheller@gmail.com']
        },
        Message: {
            Body: {
                Text: {
                    Data: text,
                    Charset: 'UTF-8'
                }
            },
            Subject: {
                Data: subject,
                Charset: 'UTF-8'
            }
        },
        Source: 'ssofrim@gmail.com'
    };
    const promise = new Promise((resolve, reject) => {
        ses.sendEmail(params, (err, data) => {
            resolve({ err, data });
        });
    });
    return promise;
}

function sendSMS(msg, phoneNumber) {
    const sns = new AWS.SNS({ apiVersion: '2010-03-31' });
    const setAttributeParams = {
        attributes: {
            DefaultSenderID: defaultSenderId
        }
    };
    const promise = new Promise((resolve, reject) => {
        sns.setSMSAttributes(setAttributeParams, (err, data) => {
            if (err) {
                resolve({ err, data });
            } else {
                const smsParams = {
                    Message: msg,
                    PhoneNumber: phoneNumber
                };
                sns.publish(smsParams, (err, data) => {
                    resolve({ err, data });
                });
            }
        });
    });
    return promise;
}


function getUserById(ID) {
    const params = {
        "Key": {
            "ID": {
                S: ID
            }
        },
        TableName: "Users"
    };
    const promise = new Promise((resolve, reject) => {
        dynamodb.getItem(params, (err, data) => {
            resolve({ err, data });
        });
    });
    return promise;
}