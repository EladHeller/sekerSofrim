﻿exports.test = (msg) => {
    console.log(msg);
}